"""Merge Overview split docs into TotalOverview.md. Run: python merge_total_overview.py"""
from pathlib import Path

DIR = Path(__file__).parent

def strip_title(text: str) -> str:
    lines = text.splitlines(keepends=True)
    if lines and lines[0].startswith("# "):
        lines = lines[1:]
        if lines and lines[0].strip() == "":
            lines = lines[1:]
    return "".join(lines)

def read(name: str) -> str:
    return (DIR / name).read_text(encoding="utf-8")

PART4 = """
# Part 4 — Editor additions

Condensed reference for editor improvements **items 1–10**. Full detail, verification steps, and file paths: [04-editor-additions.md](04-editor-additions.md).

## Summary

| # | Feature | Status |
|---|---------|--------|
| 1 | File → Save / Load | Done — `Scenes/EditorSave.json` |
| 2 | Play snapshot / Stop restore | Done — `Scenes/EditorPlaySnapshot.json` |
| 3 | Inspector + gizmo locked in Play | Done |
| 4 | Inspector light components | Done |
| 5 | Collision count in Statistics | Done |
| 6 | FPS 1-second average | Done |
| 7 | Lazy ImGui init (visible only) | Done |
| 8 | Hierarchy lists all entities | Done |
| 9 | Legend / Help window | Done |
| 10 | Debug: optional restore on Stop + Restore Snapshot | Done |

## Architecture

```mermaid
flowchart TB
  subgraph ui [Editor UI]
    Menu[File Save Load]
    TB[Play Stop]
    Hier[Hierarchy all entities]
    Insp[Inspector + lights]
    Stats[Statistics FPS collisions]
  end
  subgraph io [EditorSceneIO]
    Save[SaveScene]
    Load[LoadScene]
    Snap[BeginPlay EndPlay]
  end
  subgraph engine [Try2 Engine]
    Ser[SceneSerializer]
    Phys[PhysicsSystem + PhysicsStats]
  end
  Menu --> Save --> Ser
  Menu --> Load --> Ser
  TB --> Snap --> Ser
  Insp --> ECS[entt registry]
  Phys --> Stats
```

## Key behavior

| Topic | Description |
|-------|-------------|
| **Activation** | ImGui/DX12 init only after **`~`** when `.imgui_on` exists; `WndProc` does not create context on first message |
| **File menu** | Save/Load via `EditorSceneIO` → `Engine::SaveScene` / `LoadScene` → `SceneSerializer` |
| **Play/Stop** | Play writes snapshot; Stop returns to Edit; reload only if `restoreSceneOnStop` (default **off**); **Restore Snapshot** anytime |
| **Inspector** | All core components + **lights**; `Editor_CanEditComponents()` disables editing in Play |
| **Hierarchy** | All entity types (not tag-only) |
| **Statistics** | FPS instant + **1s average**; **collision count** via `PhysicsStats` |
| **Legend** | `Editor_DrawLegend` — shortcuts, gizmo glossary, file paths |

## Remaining gaps

| Item | Notes |
|------|-------|
| ImGui docking | Requires docking-enabled ImGui branch |
| Viewport render-to-texture | Offscreen RT for embedded view |
| Undo/redo, asset browser, material editor | PLACEHOLDER windows |
| Hierarchy parenting | Needs `HierarchyComponent` |
| GPU memory stat | PLACEHOLDER |

See [04-editor-additions.md](04-editor-additions.md) for manual verification steps.
"""

HEADER = """# Try2 Engine — Total Overview

A single merged reference for the **Try2** DirectX 12 engine ([`Try2.sln`](../LSEngine/Chapter%209%20Texturing/Try2/Try2.sln)). This document combines [README.md](README.md), [01-project-overview.md](01-project-overview.md), [02-technologies-and-patterns.md](02-technologies-and-patterns.md), [03-code-structure.md](03-code-structure.md), and condensed [04-editor-additions.md](04-editor-additions.md).

For deeper post-merge and ImGui detail, see [Changes/README.md](../Changes/README.md).

---

## Contents

### Front matter

| Section | Description |
|---------|-------------|
| [Document map](#document-map) | How this file relates to split Overview docs and Changes |
| [Scope](#scope) | In scope vs out of scope for Try2 documentation |
| [Build quick start](#build-quick-start) | Open solution, deps, optional `.imgui_on` editor |

### Part 1 — Project overview

| Section | Description |
|---------|-------------|
| [Executive summary](#executive-summary) | What Try2 is: ECS, deferred rendering, editor, JSON scenes |
| [Project lineage](#project-lineage) | Luna → Try2; merged FromScratch and ImGui branches |
| [The Try2 application](#the-try2-application) | Solution, entry point, frame loop, capability matrix |
| [Other material in LSEngine](#other-material-in-lsengine) | IMGUI_works, Common, TexColumns, duplicate shaders |
| [Work in progress and known gaps](#work-in-progress-and-known-gaps) | Vulkan stub, editor gaps, coupling issues |
| [How to build](#how-to-build) | Step-by-step build and run instructions |

### Part 2 — Technologies and patterns

| Section | Description |
|---------|-------------|
| [Core stack](#core-stack-try2-product) | C++20, D3D12, EnTT, Assimp, ImGui, nlohmann/json |
| [Dependency tiers](#dependency-tiers) | Try2, IMGUI_works, Common compiled/headers, auxiliary |
| [Architectural patterns](#architectural-patterns-try2) | Adapter, ECS pipelines, editor bridge, Edit/Play, lighting |
| [Shader pipeline](#shader-pipeline-try2shaders) | Seven HLSL files and GPU pass flow |
| [Design observations](#design-observations) | Strengths and technical debt |

### Part 3 — Code structure

| Section | Description |
|---------|-------------|
| [Try2 project layout](#try2-project-layout) | Directory tree: Try2, IMGUI_works, Common, Scenes |
| [Module responsibility table](#module-responsibility-table) | Every major module and editor hook files |
| [ECS components](#ecs-components) | Transform, mesh, camera, lights, physics, tags |
| [Diagrams A–I](#diagram-a--try2-application-lifecycle) | Lifecycle, systems, ECS, rendering, physics, build, editor binding |
| [Per-frame sequence](#per-frame-sequence-try2) | Sequence diagram for one frame |
| [Class and API quick reference](#class-and-api-quick-reference) | Application, Engine, systems, editor, renderer |
| [Source file index](#source-file-index) | Tiered file list: Try2, IMGUI_works, Common, auxiliary |
| [Key functions](#key-functions-try2) | Engine, RenderSystem, serializer, EditorSceneIO, ImGuiBridge |
| [Reading order](#reading-order-try2-contributors) | Suggested onboarding path through the codebase |

### Part 4 — Editor additions

| Section | Description |
|---------|-------------|
| [Summary](#summary) | Items 1–10 status table |
| [Architecture](#architecture) | EditorSceneIO → Engine → serializer flow |
| [Key behavior](#key-behavior) | Lazy init, save/load, Play snapshot, Inspector, stats |
| [Remaining gaps](#remaining-gaps) | Docking, viewport RT, undo, placeholders |

---

## Document map

| Resource | Use when |
|----------|----------|
| **This file (`TotalOverview.md`)** | Full architecture in one place |
| [README.md](README.md) | Short index to split docs |
| [01-project-overview.md](01-project-overview.md) | Narrative only |
| [02-technologies-and-patterns.md](02-technologies-and-patterns.md) | Stack and patterns only |
| [03-code-structure.md](03-code-structure.md) | Diagrams and file index only |
| [04-editor-additions.md](04-editor-additions.md) | Editor items 1–10 — verification and file paths |
| [Changes/README.md](../Changes/README.md) | Merge commit details, ImGui internals |

---

## Scope

| In scope | Out of scope |
|----------|--------------|
| **Product:** [`Try2/`](../LSEngine/Chapter%209%20Texturing/Try2/) and [`Try2.sln`](../LSEngine/Chapter%209%20Texturing/Try2/Try2.sln) | TexColumns application (`TexColumns.sln`) |
| **GUI (compiled):** [`LSEngine/IMGUI_works/`](../LSEngine/IMGUI_works/) via `Try2.vcxproj` | Full Dear ImGui / ImGuizmo vendor internals |
| **Scenes:** [`Try2/Scenes/`](../LSEngine/Chapter%209%20Texturing/Try2/Scenes/) (e.g. `DemoScene.json`) | |
| **Compiled deps:** `../../Common/` — `GameTimer`, `MathHelper`, `DDSTextureLoader` | Unused Luna modules in Common (`d3dApp`, `Camera`, `model`, …) |
| **Header deps:** EnTT, GLM, Assimp, nlohmann, `d3dx12.h` | Vendored library internals |
| **Auxiliary include:** `../TexColumns/CustomBuffer.h` | Duplicate `LSEngine/Shaders/` tree |

---

## Build quick start

1. Open **`LSEngine/Chapter 9 Texturing/Try2/Try2.sln`** in Visual Studio 2022.
2. Configuration: **Debug | x64**.
3. Ensure `Try2/Libs/assimp-vc143-mt.lib` is present.
4. Ensure **`LSEngine/IMGUI_works/`** exists (LSEngine repo root, sibling of `Chapter 9 Texturing/`).
5. Set `AdditionalIncludeDirectories` to `$(SolutionDir)..\\..\\Common` if the hardcoded path in `Try2.vcxproj` does not match your machine.
6. **Optional editor:** create **`.imgui_on`** beside `Try2.exe`. Press **`~`** to toggle the UI (lazy ImGui init).

---

# Part 1 — Project Overview

"""

FOOTER = """
---

*End of Total Overview. Split versions: [README](README.md) · [01](01-project-overview.md) · [02](02-technologies-and-patterns.md) · [03](03-code-structure.md) · [04](04-editor-additions.md)*
"""

def main() -> None:
    p1 = strip_title(read("01-project-overview.md"))
    p2 = strip_title(read("02-technologies-and-patterns.md"))
    p3 = strip_title(read("03-code-structure.md"))

    out = (
        HEADER
        + p1
        + "\n---\n\n# Part 2 — Technologies and Patterns\n\n"
        + p2
        + "\n---\n\n# Part 3 — Code Structure\n\n"
        + p3
        + "\n---\n\n"
        + PART4.strip()
        + "\n"
        + FOOTER
    )

    path = DIR / "TotalOverview.md"
    path.write_text(out, encoding="utf-8", newline="\n")
    print(f"Wrote {path} ({len(out.splitlines())} lines)")

if __name__ == "__main__":
    main()
